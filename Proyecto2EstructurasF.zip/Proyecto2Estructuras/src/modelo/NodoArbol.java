/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Dachapi
 */
public class NodoArbol {
    
    private Curso_Virtual data;
    private int height;
    
    private NodoArbol left;
    private NodoArbol right;

    public NodoArbol(Curso_Virtual data) {
        this.data = data;
        height = 1;
    }

    public NodoArbol() {
    }
    

    public Curso_Virtual getData() {
        return data;
    }

    public void setData(Curso_Virtual data) {
        this.data = data;
    }

    public NodoArbol getLeft() {
        return left;
    }

    public void setLeft(NodoArbol left) {
        this.left = left;
    }

    public NodoArbol getRight() {
        return right;
    }

    public void setRight(NodoArbol right) {
        this.right = right;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    
    public boolean contains(int id_Curso) {
        
        if (id_Curso == this.getData().getId_Curso()) {
            return true;
        } else if (id_Curso < this.getData().getId_Curso()) {
            if (getLeft() == null) {
                return false;
            } else {
                return getLeft().contains(id_Curso);
            }
        } else {
            if (getRight() == null) {
                return false;
            } else {
                return getRight().contains(id_Curso);
            }
        }
    }
}
