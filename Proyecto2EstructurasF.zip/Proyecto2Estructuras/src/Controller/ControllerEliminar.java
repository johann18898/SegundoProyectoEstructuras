/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Curso_Virtual;
import modelo.DBMetodos;
import modelo.MetodosAVLTree;
import vista.frmEliminarDatos;

/**
 *
 * @author vboni
 */
public class ControllerEliminar implements ActionListener {

    frmEliminarDatos vistaEliminarDatos = new frmEliminarDatos();
    Curso_Virtual curso = new Curso_Virtual();
    DBMetodos DAO = new DBMetodos();

    MetodosAVLTree avlTreeInterno = null;

    public ControllerEliminar(frmEliminarDatos frm, MetodosAVLTree avlTree) {
        this.vistaEliminarDatos = frm;
        this.vistaEliminarDatos.btnEliminar.addActionListener(this);
        avlTreeInterno = avlTree;
    }

    @Override
    public void actionPerformed(ActionEvent e) { // paso #2
        try {
            if (e.getSource() == vistaEliminarDatos.btnEliminar) {
                if (this.vistaEliminarDatos.txtIdCurso.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, llene correctamente el espacio solicitado", "Advertencia", JOptionPane.WARNING_MESSAGE);
                } else {
                    if (verificarCoincidencias()) {
                        eliminarCursos();
                        eliminarNodoArbol();
                        limpiarCampos();
                        JOptionPane.showMessageDialog(null, "Curso eliminado de la base de dato", "Eliminando nodo", JOptionPane.INFORMATION_MESSAGE);
                        this.vistaEliminarDatos.dispose();
                    } else {
                        limpiarCampos();
                        JOptionPane.showMessageDialog(null, "Solo se puede eliminar un curso ingresado anteriormente", "Advertencia", JOptionPane.WARNING_MESSAGE);
                    }
                }
            }
        } catch (NumberFormatException error) {
            limpiarCampos();
            JOptionPane.showMessageDialog(null, "Por favor, Complete el cuadro de texto con el valor correspondientes ", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }

    }
    
    public void eliminarCursos() {

        String id = vistaEliminarDatos.txtIdCurso.getText();

        curso.setId_Curso(Integer.parseInt(id));
        curso.setNombre_Curso("");
        curso.setTema_Curso("");
        curso.setCreditos(0);

        DAO.delecteDB(curso);
    }

    public void limpiarCampos() {
        vistaEliminarDatos.txtIdCurso.setText("");
    }

    public void eliminarNodoArbol() {
        String id = vistaEliminarDatos.txtIdCurso.getText();

        curso.setId_Curso(Integer.parseInt(id));
        curso.setNombre_Curso("");
        curso.setTema_Curso("");
        curso.setCreditos(0);

        avlTreeInterno.setRoot(avlTreeInterno.eliminarAVL(avlTreeInterno.getRoot(), curso));
    }
    
    public Boolean verificarCoincidencias(){
        String id = vistaEliminarDatos.txtIdCurso.getText();
        int id_Curso = 0;
        id_Curso = Integer.parseInt(id);
        
        return avlTreeInterno.getRoot().contains(id_Curso);
    }

}
