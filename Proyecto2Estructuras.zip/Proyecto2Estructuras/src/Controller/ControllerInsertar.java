/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.Curso_Virtual;
import modelo.DBMetodos;
import modelo.MetodosAVLTree;
import vista.frmInsertarDatos;

/**
 *
 * @author vboni
 */
public class ControllerInsertar implements ActionListener {

    frmInsertarDatos vistaInsetarDatos = new frmInsertarDatos();
    Curso_Virtual curso = new Curso_Virtual();
    DBMetodos DAO = new DBMetodos();

    MetodosAVLTree avlTreeInterno = null;

    public ControllerInsertar(frmInsertarDatos frm, MetodosAVLTree avlTree) {
        this.vistaInsetarDatos = frm;
        this.vistaInsetarDatos.btnAgregar.addActionListener(this);
        avlTreeInterno = avlTree;
    }

    @Override
    public void actionPerformed(ActionEvent e) { // paso #2
        if (e.getSource() == vistaInsetarDatos.btnAgregar) {
            agregarCursos();
            insertarNodoArbol();
            limpiarCampos();
            JOptionPane.showMessageDialog(null, "Curso insertado de la base de dato", "Insertando nodo", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void agregarCursos() {

        String id = vistaInsetarDatos.txtIdCurso.getText();
        String nombre = vistaInsetarDatos.txtNombreCurso.getText();
        String tema = vistaInsetarDatos.txtTemaCurso.getText();
        String creditos = vistaInsetarDatos.txtCreditos.getText();

        curso.setId_Curso(Integer.parseInt(id));
        curso.setNombre_Curso(nombre);
        curso.setTema_Curso(tema);
        curso.setCreditos(Integer.parseInt(creditos));

        DAO.insertDB(curso);
    }

    public void limpiarCampos() {
        vistaInsetarDatos.txtIdCurso.setText("");
        vistaInsetarDatos.txtNombreCurso.setText("");
        vistaInsetarDatos.txtTemaCurso.setText("");
        vistaInsetarDatos.txtCreditos.setText("");
    }

    public void insertarNodoArbol() {
        String id = vistaInsetarDatos.txtIdCurso.getText();
        String nombre = vistaInsetarDatos.txtNombreCurso.getText();
        String tema = vistaInsetarDatos.txtTemaCurso.getText();
        String creditos = vistaInsetarDatos.txtCreditos.getText();

        curso.setId_Curso(Integer.parseInt(id));
        curso.setNombre_Curso(nombre);
        curso.setTema_Curso(tema);
        curso.setCreditos(Integer.parseInt(creditos));

        avlTreeInterno.setRoot(avlTreeInterno.insert(avlTreeInterno.getRoot(), curso));
    }

}
